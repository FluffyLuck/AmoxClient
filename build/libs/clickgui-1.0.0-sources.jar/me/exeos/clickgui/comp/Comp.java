package me.exeos.clickgui.comp;

import me.exeos.clickgui.Clickgui;
import me.exeos.clickgui.setting.Setting;
import me.exeos.module.Module;
import net.minecraft.class_11908;
import net.minecraft.class_332;

public class Comp {
    public double x, y, x2, y2;
    public Clickgui parent;
    public Module module;
    public Setting setting;

    public void mouseClicked(double mouseX, double mouseY, int button) {
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
    }

    public void drawScreen(class_332 context, int mouseX, int mouseY) {
    }

    public boolean isInside(double mouseX, double mouseY, double left, double top, double right, double bottom) {
        return mouseX > left && mouseX < right && mouseY > top && mouseY < bottom;
    }

    public void keyPressed(class_11908 input) {
    }
}