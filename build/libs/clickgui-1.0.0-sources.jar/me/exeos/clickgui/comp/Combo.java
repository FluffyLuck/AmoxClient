package me.exeos.clickgui.comp;

import me.exeos.clickgui.Clickgui;
import me.exeos.clickgui.setting.Setting;
import me.exeos.module.Module;
import net.minecraft.class_2561;
import net.minecraft.class_332;

public final class Combo extends Comp {
    public Combo(double x, double y, Clickgui parent, Module module, Setting setting) {
        this.x = x;
        this.y = y;
        this.parent = parent;
        this.module = module;
        this.setting = setting;
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0 || !isInside(mouseX, mouseY, parent.posX + x - 70, parent.posY + y, parent.posX + x, parent.posY + y + 10)) {
            return;
        }
        int current = setting.getOptions().indexOf(setting.getValString());
        int next = current < 0 || current + 1 >= setting.getOptions().size() ? 0 : current + 1;
        if (!setting.getOptions().isEmpty()) {
            setting.setValString(setting.getOptions().get(next));
        }
    }

    @Override
    public void drawScreen(class_332 context, int mouseX, int mouseY) {
        int left = (int) parent.posX + (int) x - 70;
        int top = (int) parent.posY + (int) y;
        context.method_25294(left, top, left + 70, top + 10, 0xff1e1e1e);
        context.method_51439(parent.method_64506(), class_2561.method_43470(setting.getName() + ": " + setting.getValString()), left + 1, top + 1, 0xffc8c8c8, false);
    }
}