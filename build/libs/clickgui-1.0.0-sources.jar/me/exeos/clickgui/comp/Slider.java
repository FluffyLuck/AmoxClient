package me.exeos.clickgui.comp;

import me.exeos.clickgui.Clickgui;
import me.exeos.clickgui.setting.Setting;
import me.exeos.module.Module;
import net.minecraft.class_2561;
import net.minecraft.class_332;

public final class Slider extends Comp {
    private static final double TRACK_WIDTH = 90;
    private boolean dragging;

    public Slider(double x, double y, Clickgui parent, Module module, Setting setting) {
        this.x = x;
        this.y = y;
        this.parent = parent;
        this.module = module;
        this.setting = setting;
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && isInside(mouseX, mouseY, parent.posX + x - 70, parent.posY + y + 10, parent.posX + x + 20, parent.posY + y + 20)) {
            dragging = true;
            updateValue(mouseX);
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
    }

    @Override
    public void drawScreen(class_332 context, int mouseX, int mouseY) {
        if (dragging) {
            updateValue(mouseX);
        }
        double range = setting.getMax() - setting.getMin();
        double progress = range <= 0 ? 0 : (setting.getValDouble() - setting.getMin()) / range;
        int left = (int) parent.posX + (int) x - 70;
        int top = (int) parent.posY + (int) y;
        context.method_25294(left, top + 10, left + 90, top + 20, 0xff8f068f);
        context.method_25294(left, top + 10, left + (int) (TRACK_WIDTH * Math.max(0, Math.min(1, progress))), top + 20, 0xffe60ae6);
        context.method_51439(parent.method_64506(), class_2561.method_43470(setting.getName() + ": " + formatValue(setting.getValDouble())), left, top, 0xffffffff, false);
    }

    private void updateValue(double mouseX) {
        double fraction = Math.max(0, Math.min(1, (mouseX - (parent.posX + x - 70)) / TRACK_WIDTH));
        double value = setting.getMin() + fraction * (setting.getMax() - setting.getMin());
        setting.setValDouble(value);
    }

    private String formatValue(double value) {
        return setting.onlyInt() ? Integer.toString((int) value) : String.format(java.util.Locale.ROOT, "%.1f", value);
    }
}