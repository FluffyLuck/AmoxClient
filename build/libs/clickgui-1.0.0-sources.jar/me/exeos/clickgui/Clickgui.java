package me.exeos.clickgui;

import me.exeos.Tutorial;
import me.exeos.clickgui.comp.CheckBox;
import me.exeos.clickgui.comp.Combo;
import me.exeos.clickgui.comp.Comp;
import me.exeos.clickgui.comp.Slider;
import me.exeos.clickgui.setting.Setting;
import me.exeos.module.Category;
import me.exeos.module.Module;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import java.util.ArrayList;

public final class Clickgui extends class_437 {
    public double posX, posY, panelWidth, panelHeight, dragX, dragY;
    public boolean dragging;
    public Category selectedCategory;
    private Module selectedModule;
    public final ArrayList<Comp> comps = new ArrayList<>();

    public Clickgui() {
        super(class_2561.method_43470("ClickGUI"));
        selectedCategory = Category.Combat;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        posX = this.field_22789 / 2.0 - 150;
        posY = this.field_22790 / 2.0 - 100;
        panelWidth = posX + 300;
        panelHeight = posY + 200;
        dragging = false;
    }

    @Override
    protected void method_57734(class_332 context) {
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        method_25420(context, mouseX, mouseY, deltaTicks);
        if (dragging) {
            posX = mouseX - dragX;
            posY = mouseY - dragY;
        }
        panelWidth = posX + 300;
        panelHeight = posY + 200;
        context.method_25294((int) posX, (int) posY - 10, (int) panelWidth, (int) posY, 0xff640a64);
        context.method_25294((int) posX, (int) posY, (int) panelWidth, (int) panelHeight, 0xff2d2d2d);

        int offset = 0;
        for (Category category : Category.values()) {
            context.method_25294((int) posX, (int) posY + 1 + offset, (int) posX + 60, (int) posY + 15 + offset,
                    category == selectedCategory ? 0xffe60ae6 : 0xff1c1c1c);
            context.method_51439(field_22793, class_2561.method_43470(category.name()), (int) posX + 2, (int) posY + 5 + offset, 0xffaaaaaa, false);
            offset += 15;
        }

        offset = 0;
        for (Module module : Tutorial.INSTANCE.getModuleManager().getModules(selectedCategory)) {
            context.method_25294((int) posX + 65, (int) posY + 1 + offset, (int) posX + 125, (int) posY + 15 + offset,
                    module.isToggled() ? 0xffe60ae6 : 0xff1c1c1c);
            context.method_51439(field_22793, class_2561.method_43470(module.getName()), (int) posX + 67, (int) posY + 5 + offset, 0xffaaaaaa, false);
            offset += 15;
        }

        for (Comp comp : comps) {
            comp.drawScreen(context, mouseX, mouseY);
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && isInside(mouseX, mouseY, posX, posY - 10, panelWidth, posY)) {
            dragging = true;
            dragX = mouseX - posX;
            dragY = mouseY - posY;
        }

        int offset = 0;
        for (Category category : Category.values()) {
            if (button == 0 && isInside(mouseX, mouseY, posX, posY + 1 + offset, posX + 60, posY + 15 + offset)) {
                selectedCategory = category;
                comps.clear();
            }
            offset += 15;
        }

        offset = 0;
        for (Module module : Tutorial.INSTANCE.getModuleManager().getModules(selectedCategory)) {
            if (isInside(mouseX, mouseY, posX + 65, posY + 1 + offset, posX + 125, posY + 15 + offset)) {
                if (button == 0) {
                    module.toggle();
                } else if (button == 1) {
                    if (selectedModule == module) {
                        selectedModule = null;
                        comps.clear();
                    } else {
                        selectedModule = module;
                        buildComponents(module);
                    }
                }
            }
            offset += 15;
        }

        for (Comp comp : comps) {
            comp.mouseClicked(mouseX, mouseY, button);
        }
        return true;
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
        for (Comp comp : comps) {
            comp.mouseReleased(mouseX, mouseY, button);
        }
        return true;
    }

    @Override
    public boolean method_25404(class_11908 input) {
        for (Comp comp : comps) {
            comp.keyPressed(input);
        }
        return super.method_25404(input);
    }

    private void buildComponents(Module module) {
        comps.clear();
        int settingOffset = 3;
        for (Setting setting : Tutorial.INSTANCE.getSettingsManager().getSettingsByMod(module)) {
            if (setting.isCombo()) {
                comps.add(new Combo(275, settingOffset, this, selectedModule, setting));
                settingOffset += 15;
            } else if (setting.isCheck()) {
                comps.add(new CheckBox(275, settingOffset, this, selectedModule, setting));
                settingOffset += 15;
            } else if (setting.isSlider()) {
                comps.add(new Slider(275, settingOffset, this, selectedModule, setting));
                settingOffset += 25;
            }
        }
    }

    private boolean isInside(double mouseX, double mouseY, double left, double top, double right, double bottom) {
        return mouseX > left && mouseX < right && mouseY > top && mouseY < bottom;
    }
}