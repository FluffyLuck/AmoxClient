package me.exeos;

import me.exeos.clickgui.Clickgui;
import me.exeos.clickgui.setting.Setting;
import me.exeos.module.Category;
import me.exeos.module.Module;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_3966;
import org.lwjgl.glfw.GLFW;

public final class ClickGuiModClient implements ClientModInitializer {
    private static final class_304 OPEN_GUI = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.clickgui.open",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            class_304.class_11900.method_74698(class_2960.method_60655("clickgui", "controls"))
    ));

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (OPEN_GUI.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new Clickgui());
                } else if (client.field_1755 instanceof Clickgui) {
                    client.method_1507(null);
                }
            }

            Module autoAttack = Tutorial.INSTANCE.getModuleManager().getModules(Category.Combat).get(0);
            if (!autoAttack.isToggled() || client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
                return;
            }

            Setting mobs = autoAttack.getSettings().get(0);
            Setting players = autoAttack.getSettings().get(1);
            Setting range = autoAttack.getSettings().get(2);
            double attackRange = range.getValDouble();

                class_1297 target = client.field_1765 instanceof class_3966 entityHitResult
                    ? entityHitResult.method_17782()
                    : null;
                boolean validTarget = target instanceof class_1309 livingEntity
                    && livingEntity.method_5805()
                    && ((mobs.getValBoolean() && livingEntity instanceof class_1308)
                    || (players.getValBoolean() && livingEntity instanceof class_1657))
                    && client.field_1724.method_5858(target) <= attackRange * attackRange;

                if (validTarget && client.field_1724.method_7261(0.0f) >= 1.0f) {
                client.field_1761.method_2918(client.field_1724, target);
            }
        });
    }
}